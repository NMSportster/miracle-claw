---
summary: "Redirects to the current Building Plugins guide"
title: "Building plugins (redirect)"
read_when:
  - Legacy link to building-extensions
---

This page has moved. See [Building Plugins](/plugins/building-plugins).

## Related

- [Building plugins](/plugins/building-plugins)
- [Plugin architecture](/plugins/architecture)
